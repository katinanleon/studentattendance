<?php
include 'db.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signature</title>
</head>
<body>
<h1>Merci de votre presence</h1>
<br>
<a hrf="logout.php"></a>


<?php
    
      
      $email = $_SESSION["email"];
      $dup = mysqli_query($conn,"select id from student where email = '$email'");
      $row = mysqli_fetch_assoc($dup);
      $id = $row["id"];

      $insertion = "INSERT INTO attendance(iduser) VALUES('$id')";
	  mysqli_query($conn, $insertion);

	  mysqli_close($conn);


?>
</body>
</html>